This editor was first layed out in Excel
(layout_editor.xlsx).
Running "tkauto.py layout_editor.xlsx" produced
output.py (around 200 lines).
From output.py I coded editor.py (around 280 lines.)

For even an experienced Python/tkinter programmer
TkAuto can speed the design and coding process.

Editor.py demonstrates the following 
TkAuto/tkinter features: 
	Text
	Menus
	Popup menus
	clipboard handling
	messagebox
	window persistence
	filedialogs